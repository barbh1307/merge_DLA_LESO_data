This compressed file was created on 10-26-2020 and contains merged DLA LESO
data for the following periods:   

 - 2020-03-31 downloaded June 29, 2020   
 - 2020-06-30 downloaded July 5, 2020   
 - 2020-09-30 downloaded October 4, 2020   

All files were downloaded from the DLA LESO Public Data website:
https://www.dla.mil/DispositionServices/Offers/Reutilization/LawEnforcement/PublicInformation/

The data was merged using notebooks in the following repository:
https://github.com/barbh1307/merging_DLA_LESO_data

To append more recent DLA LESO data files to this dataset using those notebooks,
replace merging_DLA_LESO_data/data/merged/ folder of that repository with the
merged/ folder found in this compressed file.

__NotebooksHTMLs\__ has the output of the notebooks used to create this dataset as a series of HTML files.

__merged_checksums__ contains MD5s for all the files in the merged folder. 

MD5 for the original files (on Windows10: Get-FileHash <filename> -Algorithm MD5)
FECB8D0C6FA34A4CB7410F6F37841D02   DISP_AllStatesAndTerritories_03312020.xlsx
86C4704BE19ED4B4E2447B30A0CEC82B   DISP_AllStatesAndTerritories_06302020.xlsx
E09F02E965C2878D62363A8E64AA3CC0   DISP_AllStatesAndTerritories_09302020.xlsx
E4949C40AAFF6AD10034D966CFB295C4   DISP_Shipments_Cancellations_01012020_03312020.xlsx
7E851E3875FFB7D7839FA77C3D63B38D   DISP_Shipments_Cancellations_04012020_06302020.xlsx
49D3C5CC28CFEDE3AA9651FDB2EC3FDB   DISP_Shipments_Cancellations_07012020_09302020.xlsx


MD5 checksums were generated on Windows10 with the following command:
    Get-FileHash <filename> -Algorithm MD5
