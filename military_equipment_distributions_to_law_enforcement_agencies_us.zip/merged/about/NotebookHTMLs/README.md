Place the HTML version of the notebooks used to create this set of merged files.

Be sure to save the notebook before running the nbconvert command. Here is an example of the nbconvert command you can use to generate HTML versions of a notebook from the command line: 

        jupyter nbconvert --no-input --to html --output <path_to_folder>/<name_of_output_file>.html <name_of_notebook>.ipynb

For more information, see the [nbconvert documentation](https://nbconvert.readthedocs.io/en/latest/).
